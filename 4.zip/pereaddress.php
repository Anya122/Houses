<?php
    $id = $_POST['id'];
    header("Location: house.php?id=$id");
?>